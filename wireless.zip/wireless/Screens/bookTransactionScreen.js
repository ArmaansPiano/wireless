import React from 'react';
import { Text, View, TouchableOpacity } from 'react-native';

export default class TransactionScreen extends React.Component {
  render() {
    return (
      <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
        <Text>Issue or Return</Text>
        <TouchableOpacity style={styles.scanButton}>
          <Text style={styles.buttonText}>SCAN QR CODE</Text>
        </TouchableOpacity>
      </View>
    );
  }
}
